module.exports = {
  TOKEN: "OTM3ODc0MTAxODcwMTY2MDY2.YfiFUg.bDh5FbB19BAlXBhGeDQC2P8fKsA",
  DATABASEURL: "mongodb+srv://HappyMMBot:HappyMMBot112233!@happymmbot.uqxf2.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
  GUILDID: "938308812845248513",

  MESSAGELOGS: "https://discord.com/api/webhooks/938316718651109396/wu-VP0Dyo3up2ptkf3VZRei3UmgGQzXjwpEJCFDkSDanzfRznsz6XQZV_jFolKiaOvq5"
}
