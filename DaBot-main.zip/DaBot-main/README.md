<h1 align="center">Welcome to Lyxcode's Discord Series! 👋</h1>
<p>
  <img alt="Version" src="https://img.shields.io/badge/version-1.0.1-blue.svg?cacheSeconds=2592000" />
  <a href="#" target="_blank">
    <img alt="License: ISC" src="https://img.shields.io/badge/License-ISC-yellow.svg" />
  </a>
</p>

> This is the official repository for Lyxcode's youtube series.

## Required Installations

```sh
npm i discord.js
npm i --g --production windows-build-tools
npm i ascii-table
npm i discord-giveaways
npm i mongoose
npm i glob
npm i ms
npm i discord-html-transcripts
```

## Features

```sh
Slash Commands:
‎• /Status
‎• /Afk [status, return]

‎• /Clear [Amount] [Target?]
‎• /Giveaway [start, end, reroll, pause, unpause, delete]
‎• /Suggest [Type] [Name] [Functionality]
‎• /Ticket
‎• /Serverinfo

Context Menus:
‎• Userinfo

Events:
‎• Ready
‎• InteractionCreate
‎• messageDelete
‎• messageUpdate

```

```sh
npm run test
```

## Author

👤 **Lyxcode**

- Github: [@iLyxcode](https://github.com/iLyxcode)
- Youtube: [@Lyxcode](https://www.youtube.com/c/lyxcode)
- Discord: [@TKF Community](https://discord.gg/XRawJDx)

## Show your support

Give a ⭐️ if this project helped you!

<a href="https://ko-fi.com/I2I15YHBW">
  <img src="https://ko-fi.com/img/githubbutton_sm.svg" width="160">
</a>

---
